<template>
  <v-flex offset-md5 offset-xs2 offset-sm3>
    <v-btn href="/#/" class="button" color="success">Visualizar Formulário !</v-btn>
  </v-flex>
</template>
<script>
export default {};
</script>
<style scoped>
@media screen and (max-width: 991px) {
  .button {
    margin-top: 5%;
    margin-bottom: 5%;
  }
}

@media screen and (min-width: 992px) {
  .button {
    margin-bottom: 2%;
  }
}
</style>
