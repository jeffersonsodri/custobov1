export default class ReceitaAnual {

    constructor(formulario = '') {

        this.femeas36PesoMedioKGVivo = formulario.femeas36PesoMedioKGVivo;

        this.femeas36cabeca = formulario.femeas36cabeca;
        this.femeas36ValorUnitarioRSCabeca = formulario.femeas36ValorUnitarioRSCabeca;


        this.femeas2436PesoMedioKGVivo = formulario.femeas2436PesoMedioKGVivo;
        this.femeas2436cabeca = formulario.femeas2436cabeca;
        this.femeas2436ValorUnitarioRSCabeca = formulario.femeas2436ValorUnitarioRSCabeca;

        this.femeas1224PesoMedioKGVivo = formulario.femeas1224PesoMedioKGVivo;
        this.femeas1224cabeca = formulario.femeas1224cabeca;
        this.femeas1224ValorUnitarioRSCabeca = formulario.femeas1224ValorUnitarioRSCabeca;

        this.femeas012PesoMedioKGVivo = formulario.femeas012PesoMedioKGVivo;
        this.femeas012cabeca = formulario.femeas012cabeca;
        this.femeas012ValorUnitarioRSCabeca = formulario.femeas012ValorUnitarioRSCabeca;

        this.machos012PesoMedioKGVivo = formulario.machos012PesoMedioKGVivo;
        this.machos012cabeca = formulario.machos012cabeca;
        this.machos012ValorUnitarioRSCabeca = formulario.machos012ValorUnitarioRSCabeca;

        this.machos1224PesoMedioKGVivo = formulario.machos1224PesoMedioKGVivo;
        this.machos1224cabeca = formulario.machos1224cabeca;
        this.machos1224ValorUnitarioRSCabeca = formulario.machos1224ValorUnitarioRSCabeca;

        this.machos2436PesoMedioKGVivo = formulario.machos2436PesoMedioKGVivo;
        this.machos2436cabeca = formulario.machos2436cabeca;
        this.machos2436ValorUnitarioRSCabeca = formulario.machos2436ValorUnitarioRSCabeca;

        this.machos36PesoMedioKGVivo = formulario.machos36PesoMedioKGVivo;
        this.machos36cabeca = formulario.machos36cabeca;
        this.machos36ValorUnitarioRSCabeca = formulario.machos36ValorUnitarioRSCabeca;

        this.touroPesoMedioKGVivo = formulario.touroPesoMedioKGVivo;
        this.tourocabeca = parseInt(formulario.tourocabeca);
        this.touroValorUnitarioRSCabeca = formulario.touroValorUnitarioRSCabeca;

    }


}