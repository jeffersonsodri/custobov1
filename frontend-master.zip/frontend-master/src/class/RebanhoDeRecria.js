export default class RebanhoDeRecria {

    constructor(formulario = '') {

        this.femeas36PesoInicial = formulario.femeas36PesoInicial;
        this.femeas36PesoFinal = formulario.femeas36PesoFinal;
        this.femeas36Valor = formulario.femeas36Valor;
        this.femeas36CabecasInicial = formulario.femeas36CabecasInicial;
        this.femeas36CabecasFinal = formulario.femeas36CabecasFinal;
        this.femeas2436PesoInicial = formulario.femeas2436PesoInicial;
        this.femeas2436PesoFinal = formulario.femeas2436PesoFinal;
        this.femeas2436Valor = formulario.femeas2436Valor;
        this.femeas2436CabecasInicial = formulario.femeas2436CabecasInicial;
        this.femeas2436CabecasFinal = formulario.femeas2436CabecasFinal;
        this.femeas1224PesoInicial = formulario.femeas1224PesoInicial;
        this.femeas1224PesoFinal = formulario.femeas1224PesoFinal;
        this.femeas1224Valor = formulario.femeas1224Valor;
        this.femeas1224CabecasInicial = formulario.femeas1224CabecasInicial;
        this.femeas1224CabecasFinal = formulario.femeas1224CabecasFinal;
        this.femeas012PesoInicial = formulario.femeas012PesoInicial;
        this.femeas012PesoFinal = formulario.femeas012PesoFinal;
        this.femeas012Valor = formulario.femeas012Valor;
        this.femeas012CabecasInicial = formulario.femeas012CabecasInicial;
        this.femeas012CabecasFinal = formulario.femeas012CabecasFinal;
        this.machos012PesoInicial = formulario.machos012PesoInicial;
        this.machos012PesoFinal = formulario.machos012PesoFinal;
        this.machos012Valor = formulario.machos012Valor;
        this.machos012CabecasInicial = formulario.machos012CabecasInicial;
        this.machos012CabecasFinal = formulario.machos012CabecasFinal;
        this.machos1224PesoInicial = formulario.machos1224PesoInicial;
        this.machos1224PesoFinal = formulario.machos1224PesoFinal;
        this.machos1224Valor = formulario.machos1224Valor;
        this.machos2436PesoInicial = formulario.machos2436PesoInicial;
        this.machos2436PesoFinal = formulario.machos2436PesoFinal;
        this.machos1224CabecasInicial = formulario.machos1224CabecasInicial;
        this.machos2436Valor = formulario.machos2436Valor;
        this.machos1224CabecasFinal = formulario.machos1224CabecasFinal;
        this.machos2436CabecasInicial = formulario.machos2436CabecasInicial;
        this.machos2436CabecasFinal = formulario.machos2436CabecasFinal;
        this.machos36PesoInicial = formulario.machos36PesoInicial;
        this.machos36PesoFinal = formulario.machos36PesoFinal;
        this.machos36Valor = formulario.machos36Valor;
        this.machos36CabecasInicial = formulario.machos36CabecasInicial;
        this.machos36CabecasFinal = formulario.machos36CabecasFinal;

    }


}