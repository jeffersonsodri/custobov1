export default class ReceitaAnualAbate {

    constructor(formulario = '') {

        this.femeas36PesoMedioKGVivo = formulario.femeas36PesoMedioKGVivo;

        this.femeas36PesoMedioCarcaca = formulario.femeas36PesoMedioCarcaca;
        this.femeas36cabeca = formulario.femeas36cabeca;
        this.femeas36ValorUnitarioRS = formulario.femeas36ValorUnitarioRS;


        this.femeas2436PesoMedioKGVivo = formulario.femeas2436PesoMedioKGVivo;

        this.femeas2436PesoMedioCarcaca = formulario.femeas2436PesoMedioCarcaca;
        this.femeas2436cabeca = formulario.femeas2436cabeca;
        this.femeas2436ValorUnitarioRS = formulario.femeas2436ValorUnitarioRS;

        this.femeas1224PesoMedioKGVivo = formulario.femeas1224PesoMedioKGVivo;

        this.femeas1224PesoMedioCarcaca = formulario.femeas1224PesoMedioCarcaca;
        this.femeas1224cabeca = formulario.femeas1224cabeca;
        this.femeas1224ValorUnitarioRS = formulario.femeas1224ValorUnitarioRS;

        this.machos1224PesoMedioKGVivo = formulario.machos1224PesoMedioKGVivo;
        this.machos1224PesoMedioCarcaca = formulario.machos1224PesoMedioCarcaca;
        this.machos1224cabeca = formulario.machos1224cabeca;
        this.machos1224ValorUnitarioRS = formulario.machos1224ValorUnitarioRS;

        this.machos2436PesoMedioKGVivo = formulario.machos2436PesoMedioKGVivo;
        this.machos2436PesoMedioCarcaca = formulario.machos2436PesoMedioCarcaca;
        this.machos2436cabeca = formulario.machos2436cabeca;
        this.machos2436ValorUnitarioRS = formulario.machos2436ValorUnitarioRS;

        this.machos36PesoMedioKGVivo = formulario.machos36PesoMedioKGVivo;
        this.machos36PesoMedioCarcaca = formulario.machos36PesoMedioCarcaca;
        this.machos36cabeca = formulario.machos36cabeca;
        this.machos36ValorUnitarioRS = formulario.machos36ValorUnitarioRS;

    }


}