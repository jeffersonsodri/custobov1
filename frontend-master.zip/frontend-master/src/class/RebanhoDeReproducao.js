export default class RebanhoDeReproducao {

    constructor(formulario = '') {

        this.touroPesoMedio = formulario.touroPesoMedio;
        this.touroCabecaInicial = formulario.touroCabecaInicial;
        this.touroCabecaFinal = formulario.touroCabecaFinal;
        this.touroValor = formulario.touroValor;
        this.vacaMatrizPesoMedio = formulario.vacaMatrizPesoMedio;
        this.vacaMatrizCabecaInicial = formulario.vacaMatrizCabecaInicial;
        this.vacaMatrizCabecaFinal = formulario.vacaMatrizCabecaFinal;
        this.vacaMatrizValor = formulario.vacaMatrizValor;


    }





}