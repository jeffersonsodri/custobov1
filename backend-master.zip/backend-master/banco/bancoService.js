const fazendaSchema = require('./bancoDadosRebanho');
const _ = require('lodash')

fazendaSchema.methods(['get', 'post', 'put', 'delete']);

fazendaSchema.updateOptions({new: true, runValidators: true});

fazendaSchema.after('post', sendErrorsOrNext).after('put', sendErrorsOrNext)

/** 
 * Para tratar erros no FrontEnd
*/
function sendErrorsOrNext(req, res, next) {
    const bundle = res.locals.bundle;

    if(bundle.errors) {
        var errors = parseErrors(bundle.errors)
        res.status(500).json({errors})
    } else{
        next()
    }
}
/**
 * 
 * @param {*} ndoeRestfulErrors 
 * @returns errors
 */
function parseErrors(ndoeRestfulErrors) {
    const errors = []
    //Para colocar a mensagem de erro do padrão dentro da variável erros
    _.forIn(ndoeRestfulErrors, error => {
        return errors.push(error.message);
    })
    return errors;
}



module.exports = fazendaSchema;