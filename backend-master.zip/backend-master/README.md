## Executando o arquivo 

1. Instalando as dependências =: node_modules 

>``npm install ``

## # Executando o mongoDB
 Para executar o mongoDB é necessário ter o mongo instalado e configurado localmente na sua máquina. 

1. Abra dois terminais cmd com WINDOWS + R ou do linux
    
    1.1. Em 1 deles digite o comando e deixe aberto:  

    > `` mongod ``
    
    1.2. No outro digite "mongo"(depois do primeiro passo).
    
    > `` mongo -host 10.88.76.25 -port 27018 ``
    
**`` Obs.: O passo 1 é executar o servidor e cliente do banco``**

2. Para executar o arquivo
 


3. Como é uma instalação backEnd você deve usar o PostMan para fazer execuções de ``[('get', 'post', 'put', 'delete')]``

### Mas...

 >  ``Se digitar localhost:3000/api/dadosrebanho pode ser que apareça algo por enquanto pelo método GET``
